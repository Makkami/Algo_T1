Indicaciones:
- El problema 1 está en 'p1.py', el 2 en 'p2.py' y el problema 3 está separado en 2, la multiplicación de (knxn)*(nxkn) está en 'p3_1.cpp', mientras que el caso(nxkn)*(knxn) está en 'p3_2.cpp'.
- Existen otros códigos que complementan al programa en c++, estos no se deben modificar ni sacar de la carpeta.
- El makefile se ejecuta sólo con el comando 'make'. No hay instrucciones para los programas en python.
- Los programas en python fueron hechos y probados en python 3.8.2.
- Luego de ejecutar el make los ejecutables tendrán el mismo nombre que el código fuente salvo por la extensión que será '.out'.